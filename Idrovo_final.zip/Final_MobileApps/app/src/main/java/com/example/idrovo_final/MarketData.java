package com.example.idrovo_final;

public class MarketData {

    private String coinName;
    private String coinPrice;
    private String coinID;

    public MarketData(){}

    public String getCoinName() {return coinName; }
    public String getCoinPrice() {return coinPrice;}
    public String getCoinID() {return coinID;}

    public void setCoinName(String coinName) {this.coinName = coinName;}
    public void setCoinPrice(String coinPrice) {this.coinPrice = coinPrice;}
    public void setCoinID(String coinID) {this.coinID = coinID;}

}
